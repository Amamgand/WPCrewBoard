<?php
/**
 * Plugin Name: CrewBoard
 * Description: Einfaches Mitgliederportal und Dienstplanung für Events Manager.
 * Version: 0.2.0
 * Author: Bühne-Schlachthof Eisenach e. V.
 * Text Domain: crewboard
 * Requires at least: 6.4
 * Requires PHP: 8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class CrewBoard {
    const VERSION = '0.2.0';
    const META_SERVICES = '_crewboard_services';
    const PAGE_OPTION = 'crewboard_portal_page_id';
    const META_TEAMS = '_crewboard_teams';
    const META_LEVEL = '_crewboard_level';
    const OPTION_SELF_ASSIGN  = 'crewboard_self_assign';
    const OPTION_CUSTOM_TEAMS  = 'crewboard_custom_teams';

    public static function init(): void {
        add_action( 'plugins_loaded', array( __CLASS__, 'load_textdomain' ) );
        add_action( 'admin_notices', array( __CLASS__, 'dependency_notice' ) );
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
        add_action( 'admin_post_crewboard_save_members', array( __CLASS__, 'save_members' ) );
        add_action( 'admin_post_crewboard_save_settings', array( __CLASS__, 'save_settings' ) );
        add_action( 'add_meta_boxes_event', array( __CLASS__, 'add_event_metabox' ) );
        add_action( 'save_post_event', array( __CLASS__, 'save_event_services' ), 20, 2 );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'frontend_assets' ) );
        add_shortcode( 'crewboard', array( __CLASS__, 'shortcode_portal' ) );
        add_action( 'admin_post_crewboard_claim_service', array( __CLASS__, 'claim_service' ) );
        add_action( 'admin_post_crewboard_save_event_services', array( __CLASS__, 'save_services_from_admin_page' ) );
        add_action( 'admin_post_crewboard_respond_service', array( __CLASS__, 'respond_service' ) );
        add_filter( 'login_redirect', array( __CLASS__, 'login_redirect' ), 20, 3 );
    }

    public static function activate(): void {
        if ( false === get_option( self::OPTION_SELF_ASSIGN, false ) ) {
            add_option( self::OPTION_SELF_ASSIGN, '1' );
        }
        if ( false === get_option( self::OPTION_CUSTOM_TEAMS, false ) ) {
            add_option( self::OPTION_CUSTOM_TEAMS, array() );
        }
        $page_id = (int) get_option( self::PAGE_OPTION );
        if ( $page_id && get_post( $page_id ) ) {
            return;
        }

        $existing = get_page_by_path( 'intern' );
        if ( $existing instanceof WP_Post ) {
            update_option( self::PAGE_OPTION, $existing->ID );
            return;
        }

        $page_id = wp_insert_post(
            array(
                'post_title'   => 'CrewBoard',
                'post_name'    => 'intern',
                'post_content' => '[crewboard]',
                'post_status'  => 'publish',
                'post_type'    => 'page',
            ),
            true
        );

        if ( ! is_wp_error( $page_id ) ) {
            update_option( self::PAGE_OPTION, (int) $page_id );
        }
    }

    public static function load_textdomain(): void {
        load_plugin_textdomain( 'crewboard', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }

    public static function dependency_notice(): void {
        if ( current_user_can( 'activate_plugins' ) && ! post_type_exists( 'event' ) ) {
            echo '<div class="notice notice-warning"><p><strong>CrewBoard:</strong> Der Beitragstyp <code>event</code> wurde nicht gefunden. Bitte Events Manager aktivieren.</p></div>';
        }
    }

    public static function add_event_metabox( WP_Post $post ): void {
        add_meta_box(
            'crewboard-services',
            'CrewBoard – Dienste & Aufgaben',
            array( __CLASS__, 'render_event_metabox' ),
            'event',
            'normal',
            'high'
        );
    }

    public static function render_event_metabox( WP_Post $post ): void {
        wp_nonce_field( 'crewboard_save_services', 'crewboard_nonce' );
        $services = self::get_services( $post->ID );
        $users = get_users(
            array(
                'orderby' => 'display_name',
                'order'   => 'ASC',
                'fields'  => array( 'ID', 'display_name' ),
            )
        );
        $users = array_values( array_filter( $users, static fn( $user ): bool => self::user_is_eligible( (int) $user->ID, '' ) ) );
        ?>
        <p>Hier werden Dienste angelegt und Mitgliedern zugewiesen. Freie Plätze erscheinen später im Mitgliederportal.</p>
        <table class="widefat striped" id="crewboard-services-table">
            <thead>
                <tr>
                    <th>Dienst/Aufgabe</th>
                    <th>Beginn</th>
                    <th>Ende</th>
                    <th>Bedarf</th>
                    <th>Team</th>
                    <th>Zugewiesene Mitglieder</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php
            if ( empty( $services ) ) {
                $services[] = self::empty_service();
            }
            foreach ( $services as $index => $service ) {
                self::render_service_row( $index, $service, $users );
            }
            ?>
            </tbody>
        </table>
        <p><button type="button" class="button" id="crewboard-add-service">+ Dienst hinzufügen</button></p>
        <script type="text/template" id="crewboard-service-template">
            <?php self::render_service_row( '__INDEX__', self::empty_service(), $users ); ?>
        </script>
        <?php
    }

    private static function render_service_row( $index, array $service, array $users ): void {
        $assigned = array_map( 'intval', $service['assigned'] ?? array() );
        ?>
        <tr class="crewboard-service-row">
            <td>
                <input type="hidden" name="crewboard_services[<?php echo esc_attr( (string) $index ); ?>][id]" value="<?php echo esc_attr( $service['id'] ?? wp_generate_uuid4() ); ?>">
                <input type="text" name="crewboard_services[<?php echo esc_attr( (string) $index ); ?>][title]" value="<?php echo esc_attr( $service['title'] ?? '' ); ?>" placeholder="z. B. Theke" required>
            </td>
            <td><input type="datetime-local" name="crewboard_services[<?php echo esc_attr( (string) $index ); ?>][start]" value="<?php echo esc_attr( $service['start'] ?? '' ); ?>"></td>
            <td><input type="datetime-local" name="crewboard_services[<?php echo esc_attr( (string) $index ); ?>][end]" value="<?php echo esc_attr( $service['end'] ?? '' ); ?>"></td>
            <td><input type="number" min="1" max="50" name="crewboard_services[<?php echo esc_attr( (string) $index ); ?>][needed]" value="<?php echo esc_attr( (string) ( $service['needed'] ?? 1 ) ); ?>" class="small-text"></td>
            <td>
                <select name="crewboard_services[<?php echo esc_attr( (string) $index ); ?>][team]">
                    <option value="">Alle Teams</option>
                    <?php foreach ( self::teams() as $team_key => $team_label ) : ?>
                        <option value="<?php echo esc_attr( $team_key ); ?>" <?php selected( $service['team'] ?? '', $team_key ); ?>><?php echo esc_html( $team_label ); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
            <td>
                <div class="crewboard-member-checkboxes">
                    <?php
                    $responses    = is_array( $service['responses'] ?? null ) ? $service['responses'] : array();
                    $status_icons = array( 'accepted' => '✓', 'denied' => '✗', 'pending' => '–' );
                    foreach ( $users as $user ) :
                        $is_assigned = in_array( (int) $user->ID, $assigned, true );
                        $resp        = $is_assigned ? ( $responses[ (string) $user->ID ] ?? array( 'status' => 'pending', 'reason' => '' ) ) : null;
                        ?>
                        <label>
                            <input type="checkbox" name="crewboard_services[<?php echo esc_attr( (string) $index ); ?>][assigned][]" value="<?php echo esc_attr( (string) $user->ID ); ?>" <?php checked( $is_assigned ); ?>>
                            <?php echo esc_html( $user->display_name ); ?>
                            <?php if ( $resp ) :
                                $reason_attr = ! empty( $resp['reason'] ) ? ' title="' . esc_attr( $resp['reason'] ) . '"' : ''; ?>
                                <span class="crewboard-admin-response crewboard-response-<?php echo esc_attr( $resp['status'] ); ?>"<?php echo $reason_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php echo esc_html( $status_icons[ $resp['status'] ] ?? '–' ); ?></span>
                            <?php endif; ?>
                        </label>
                    <?php endforeach; ?>
                </div>
            </td>
            <td><button type="button" class="button-link-delete crewboard-remove-service">Entfernen</button></td>
        </tr>
        <?php
    }

    private static function empty_service(): array {
        return array(
            'id'       => wp_generate_uuid4(),
            'title'    => '',
            'start'    => '',
            'end'      => '',
            'needed'   => 1,
            'team'     => '',
            'assigned' => array(),
        );
    }

    public static function save_event_services( int $post_id, WP_Post $post ): void {
        if ( ! isset( $_POST['crewboard_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['crewboard_nonce'] ) ), 'crewboard_save_services' ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        self::persist_services_from_request( $post_id );
    }

    private static function sanitize_datetime_local( string $value ): string {
        $value = sanitize_text_field( $value );
        return preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $value ) ? $value : '';
    }

    public static function admin_assets( string $hook ): void {
        $screen = get_current_screen();
        $is_event_editor = $screen && 'event' === $screen->post_type;
        $is_crewboard_page = str_contains( $hook, 'crewboard' );
        if ( ! $is_event_editor && ! $is_crewboard_page ) {
            return;
        }
        wp_enqueue_script( 'crewboard-admin', plugins_url( 'assets/admin.js', __FILE__ ), array(), self::VERSION, true );
        wp_enqueue_style( 'crewboard-admin', plugins_url( 'assets/admin.css', __FILE__ ), array(), self::VERSION );
    }

    public static function frontend_assets(): void {
        if ( is_singular() && has_shortcode( (string) get_post_field( 'post_content', get_queried_object_id() ), 'crewboard' ) ) {
            wp_enqueue_style( 'crewboard', plugins_url( 'assets/crewboard.css', __FILE__ ), array(), self::VERSION );
            wp_enqueue_script( 'crewboard', plugins_url( 'assets/crewboard.js', __FILE__ ), array(), self::VERSION, true );
        }
    }

    public static function shortcode_portal(): string {
        if ( ! is_user_logged_in() ) {
            $login_url = wp_login_url( get_permalink() );
            return '<div class="crewboard-login"><h2>CrewBoard</h2><p>Bitte melde dich an, um deine Termine und Dienste zu sehen.</p><p><a class="crewboard-button" href="' . esc_url( $login_url ) . '">Anmelden</a></p></div>';
        }

        $user = wp_get_current_user();
        $month = isset( $_GET['cb_month'] ) ? sanitize_text_field( wp_unslash( $_GET['cb_month'] ) ) : wp_date( 'Y-m' );
        if ( ! preg_match( '/^\d{4}-\d{2}$/', $month ) ) {
            $month = wp_date( 'Y-m' );
        }

        ob_start();
        ?>
        <div class="crewboard-wrap">
            <header class="crewboard-hero">
                <div>
                    <span class="crewboard-eyebrow">CrewBoard</span>
                    <h1>Hallo <?php echo esc_html( $user->display_name ); ?> 👋</h1>
                    <p>Hier findest du deine nächsten Dienste und alle geplanten Veranstaltungen.</p>
                </div>
                <a class="crewboard-logout" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">Abmelden</a>
            </header>

            <?php
            $cb_param = isset( $_GET['crewboard'] ) ? sanitize_key( wp_unslash( $_GET['crewboard'] ) ) : '';
            if ( 'responded_accepted' === $cb_param ) : ?>
                <div class="crewboard-notice crewboard-notice-success">✓ Danke! Deine Zusage wurde gespeichert.</div>
            <?php elseif ( 'responded_denied' === $cb_param ) : ?>
                <div class="crewboard-notice crewboard-notice-warning">Deine Ablehnung wurde gespeichert. Die Koordination wurde informiert.</div>
            <?php endif; ?>
            <?php echo self::render_my_services( (int) $user->ID ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <?php echo self::render_open_services( (int) $user->ID ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <?php echo self::render_calendar( $month, (int) $user->ID ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    private static function render_my_services( int $user_id ): string {
        $items = self::collect_services( $user_id, 'assigned' );
        ob_start();
        ?>
        <section class="crewboard-section">
            <div class="crewboard-section-title"><h2>Meine nächsten Dienste</h2><span><?php echo esc_html( (string) count( $items ) ); ?></span></div>
            <?php if ( empty( $items ) ) : ?>
                <div class="crewboard-empty">Du bist aktuell für keinen kommenden Dienst eingetragen.</div>
            <?php else : ?>
                <div class="crewboard-cards">
                    <?php foreach ( array_slice( $items, 0, 8 ) as $item ) : ?>
                        <?php echo self::service_card( $item, false, $user_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
        <?php
        return (string) ob_get_clean();
    }

    private static function render_open_services( int $user_id ): string {
        $items = self::collect_services( $user_id, 'open' );
        ob_start();
        ?>
        <section class="crewboard-section">
            <div class="crewboard-section-title"><h2>Offene Dienste</h2><span><?php echo esc_html( (string) count( $items ) ); ?></span></div>
            <?php if ( empty( $items ) ) : ?>
                <div class="crewboard-empty">Aktuell sind alle eingetragenen Dienste vollständig besetzt.</div>
            <?php else : ?>
                <div class="crewboard-cards">
                    <?php foreach ( array_slice( $items, 0, 8 ) as $item ) : ?>
                        <?php echo self::service_card( $item, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
        <?php
        return (string) ob_get_clean();
    }

    private static function service_card( array $item, bool $claimable, int $user_id = 0 ): string {
        $service        = $item['service'];
        $event          = $item['event'];
        $when           = self::format_service_time( $service, $event );
        $assigned_count = count( $service['assigned'] ?? array() );
        $needed         = max( 1, (int) ( $service['needed'] ?? 1 ) );

        // Response state for the viewing member (only set when called for assigned services).
        $responses = is_array( $service['responses'] ?? null ) ? $service['responses'] : array();
        $response  = $user_id > 0 ? ( $responses[ (string) $user_id ] ?? array( 'status' => 'pending', 'reason' => '' ) ) : array();
        $status    = $response['status'] ?? '';

        ob_start();
        ?>
        <article class="crewboard-card<?php echo 'denied' === $status ? ' crewboard-card-denied' : ''; ?>">
            <div class="crewboard-card-date"><?php echo esc_html( self::event_date_label( $event ) ); ?></div>
            <h3><?php echo esc_html( get_the_title( $event ) ); ?></h3>
            <p class="crewboard-service-name"><?php echo esc_html( $service['title'] ); ?></p>
            <p><?php echo esc_html( $when ); ?></p>
            <p class="crewboard-capacity"><?php echo esc_html( sprintf( '%d von %d besetzt', $assigned_count, $needed ) ); ?></p>

            <?php if ( '' !== $status ) :
                $badge_map = array(
                    'accepted' => array( 'label' => '✓ Zugesagt',   'cls' => 'accepted' ),
                    'denied'   => array( 'label' => '✗ Abgelehnt',  'cls' => 'denied' ),
                    'pending'  => array( 'label' => '– Ausstehend', 'cls' => 'pending' ),
                );
                $badge = $badge_map[ $status ] ?? $badge_map['pending'];
                ?>
                <p class="crewboard-response-badge crewboard-response-<?php echo esc_attr( $badge['cls'] ); ?>"><?php echo esc_html( $badge['label'] ); ?></p>
                <?php if ( 'denied' === $status && ! empty( $response['reason'] ) ) : ?>
                    <p class="crewboard-response-reason"><?php echo esc_html( $response['reason'] ); ?></p>
                <?php endif; ?>

                <div class="crewboard-respond-actions">
                    <?php if ( 'accepted' !== $status ) : ?>
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                            <input type="hidden" name="action"          value="crewboard_respond_service">
                            <input type="hidden" name="event_id"        value="<?php echo esc_attr( (string) $event->ID ); ?>">
                            <input type="hidden" name="service_id"      value="<?php echo esc_attr( $service['id'] ); ?>">
                            <input type="hidden" name="response_status" value="accepted">
                            <?php wp_nonce_field( 'crewboard_respond_' . $event->ID . '_' . $service['id'], 'crewboard_respond_nonce' ); ?>
                            <button class="crewboard-button crewboard-button-accept" type="submit">✓ Zusagen</button>
                        </form>
                    <?php endif; ?>
                    <?php if ( 'denied' !== $status ) : ?>
                        <div class="crewboard-deny-wrap">
                            <button type="button" class="crewboard-button crewboard-button-deny crewboard-deny-toggle">✗ Ablehnen</button>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="crewboard-deny-form" hidden>
                                <input type="hidden" name="action"          value="crewboard_respond_service">
                                <input type="hidden" name="event_id"        value="<?php echo esc_attr( (string) $event->ID ); ?>">
                                <input type="hidden" name="service_id"      value="<?php echo esc_attr( $service['id'] ); ?>">
                                <input type="hidden" name="response_status" value="denied">
                                <?php wp_nonce_field( 'crewboard_respond_' . $event->ID . '_' . $service['id'], 'crewboard_respond_nonce' ); ?>
                                <textarea name="response_reason" class="crewboard-deny-reason" rows="2" placeholder="Grund (optional) …"></textarea>
                                <button class="crewboard-button crewboard-button-deny" type="submit">Ablehnung senden</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if ( $claimable && '1' === get_option( self::OPTION_SELF_ASSIGN, '1' ) ) : ?>
                <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
                    <input type="hidden" name="action"     value="crewboard_claim_service">
                    <input type="hidden" name="event_id"   value="<?php echo esc_attr( (string) $event->ID ); ?>">
                    <input type="hidden" name="service_id" value="<?php echo esc_attr( $service['id'] ); ?>">
                    <?php wp_nonce_field( 'crewboard_claim_' . $event->ID . '_' . $service['id'], 'crewboard_claim_nonce' ); ?>
                    <button class="crewboard-button" type="submit">Ich übernehme das</button>
                </form>
            <?php endif; ?>
        </article>
        <?php
        return (string) ob_get_clean();
    }

    private static function render_calendar( string $month, int $user_id ): string {
        $tz    = wp_timezone();
        $first = DateTimeImmutable::createFromFormat( '!Y-m-d', $month . '-01', $tz );
        if ( ! $first ) {
            return '';
        }

        $last       = $first->modify( 'last day of this month' );
        $prev       = $first->modify( '-1 month' )->format( 'Y-m' );
        $next       = $first->modify( '+1 month' )->format( 'Y-m' );
        $events     = self::get_events_between( $first, $last );
        $portal_url = get_permalink();
        $today      = wp_date( 'Y-m-d', null, $tz );

        // Build per-date payload (title + user task info) for JS detail panel.
        $day_data = array();
        foreach ( $events as $event ) {
            $date = self::event_start_date( $event );
            if ( ! $date ) {
                continue;
            }
            $key      = $date->format( 'Y-m-d' );
            $services = self::get_services( $event->ID );
            $mine     = array_values(
                array_filter(
                    $services,
                    fn( array $s ): bool => in_array( $user_id, array_map( 'intval', $s['assigned'] ?? array() ), true )
                )
            );
            $day_data[ $key ][] = array(
                'title'       => get_the_title( $event ),
                'has_my_task' => ! empty( $mine ),
                'my_services' => array_column( $mine, 'title' ),
            );
        }

        $start_dow     = (int) $first->format( 'N' ); // 1 = Mon … 7 = Sun
        $days_in_month = (int) $last->format( 'j' );

        ob_start();
        ?>
        <section class="crewboard-section crewboard-calendar-section">
            <div class="crewboard-calendar-head">
                <a href="<?php echo esc_url( add_query_arg( 'cb_month', $prev, $portal_url ) ); ?>" aria-label="Vorheriger Monat">‹</a>
                <h2><?php echo esc_html( wp_date( 'F Y', $first->getTimestamp(), $tz ) ); ?></h2>
                <a href="<?php echo esc_url( add_query_arg( 'cb_month', $next, $portal_url ) ); ?>" aria-label="Nächster Monat">›</a>
            </div>

            <div class="crewboard-cal-grid" id="crewboard-cal-grid">
                <?php foreach ( array( 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So' ) as $wd ) : ?>
                    <div class="crewboard-cal-wday"><?php echo esc_html( $wd ); ?></div>
                <?php endforeach; ?>

                <?php for ( $i = 1; $i < $start_dow; $i++ ) : ?>
                    <div class="crewboard-cal-cell crewboard-cal-empty"></div>
                <?php endfor; ?>

                <?php for ( $d = 1; $d <= $days_in_month; $d++ ) : ?>
                    <?php
                    $key      = sprintf( '%s-%02d', $month, $d );
                    $evts     = $day_data[ $key ] ?? array();
                    $has_evt  = ! empty( $evts );
                    $has_mine = $has_evt && (bool) array_filter( $evts, fn( array $e ) => $e['has_my_task'] );
                    $is_today = $key === $today;
                    $classes  = 'crewboard-cal-cell';
                    if ( $has_evt )  { $classes .= ' has-event'; }
                    if ( $has_mine ) { $classes .= ' has-mine'; }
                    if ( $is_today ) { $classes .= ' is-today'; }
                    ?>
                    <div class="<?php echo esc_attr( $classes ); ?>"
                        <?php if ( $has_evt ) : ?>data-events="<?php echo esc_attr( (string) wp_json_encode( $evts ) ); ?>"<?php endif; ?>>
                        <span class="crewboard-cal-num"><?php echo esc_html( (string) $d ); ?></span>
                        <?php if ( $has_evt ) : ?>
                            <div class="crewboard-cal-dots">
                                <?php foreach ( $evts as $evt ) : ?>
                                    <span class="crewboard-cal-dot<?php echo $evt['has_my_task'] ? ' is-mine' : ''; ?>"></span>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endfor; ?>
            </div>

            <div class="crewboard-cal-panel" id="crewboard-cal-panel" hidden></div>
        </section>
        <?php
        return (string) ob_get_clean();
    }

    private static function collect_services( int $user_id, string $mode ): array {
        $start = new DateTimeImmutable( 'today', wp_timezone() );
        $end = $start->modify( '+12 months' );
        $events = self::get_events_between( $start, $end );
        $items = array();
        foreach ( $events as $event ) {
            foreach ( self::get_services( $event->ID ) as $service ) {
                $assigned = array_map( 'intval', $service['assigned'] ?? array() );
                $needed = max( 1, (int) ( $service['needed'] ?? 1 ) );
                if ( 'assigned' === $mode && in_array( $user_id, $assigned, true ) ) {
                    $items[] = array( 'event' => $event, 'service' => $service );
                }
                if ( 'open' === $mode && self::user_is_eligible( $user_id, (string) ( $service['team'] ?? '' ) ) && ! in_array( $user_id, $assigned, true ) && count( $assigned ) < $needed ) {
                    $items[] = array( 'event' => $event, 'service' => $service );
                }
            }
        }
        usort(
            $items,
            static function ( array $a, array $b ): int {
                return strcmp( self::service_sort_key( $a['service'], $a['event'] ), self::service_sort_key( $b['service'], $b['event'] ) );
            }
        );
        return $items;
    }

    private static function service_sort_key( array $service, WP_Post $event ): string {
        return ! empty( $service['start'] ) ? $service['start'] : ( self::event_start_date( $event )?->format( 'Y-m-d\TH:i' ) ?? '9999-12-31T23:59' );
    }

    public static function claim_service(): void {
        if ( ! is_user_logged_in() ) {
            auth_redirect();
        }
        $event_id = isset( $_POST['event_id'] ) ? absint( $_POST['event_id'] ) : 0;
        $service_id = isset( $_POST['service_id'] ) ? sanitize_text_field( wp_unslash( $_POST['service_id'] ) ) : '';
        $nonce = isset( $_POST['crewboard_claim_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['crewboard_claim_nonce'] ) ) : '';
        if ( ! $event_id || ! $service_id || ! wp_verify_nonce( $nonce, 'crewboard_claim_' . $event_id . '_' . $service_id ) ) {
            wp_die( 'Ungültige Anfrage.', 'CrewBoard', array( 'response' => 403 ) );
        }

        if ( '1' !== get_option( self::OPTION_SELF_ASSIGN, '1' ) ) {
            wp_die( 'Die Selbstzuweisung ist deaktiviert.', 'CrewBoard', array( 'response' => 403 ) );
        }

        $services = self::get_services( $event_id );
        $user_id = get_current_user_id();
        foreach ( $services as &$service ) {
            if ( $service_id !== ( $service['id'] ?? '' ) ) {
                continue;
            }
            if ( ! self::user_is_eligible( $user_id, (string) ( $service['team'] ?? '' ) ) ) {
                wp_die( 'Du bist für diesen Team-Dienst nicht freigeschaltet.', 'CrewBoard', array( 'response' => 403 ) );
            }
            $assigned = array_values( array_unique( array_map( 'intval', $service['assigned'] ?? array() ) ) );
            $needed = max( 1, (int) ( $service['needed'] ?? 1 ) );
            if ( ! in_array( $user_id, $assigned, true ) && count( $assigned ) < $needed ) {
                $assigned[] = $user_id;
                $service['assigned'] = $assigned;
            }
            break;
        }
        unset( $service );
        update_post_meta( $event_id, self::META_SERVICES, $services );
        wp_safe_redirect( add_query_arg( 'crewboard', 'claimed', self::portal_url() ) );
        exit;
    }

    public static function respond_service(): void {
        if ( ! is_user_logged_in() ) {
            auth_redirect();
        }
        $event_id   = isset( $_POST['event_id'] )               ? absint( $_POST['event_id'] )                                       : 0;
        $service_id = isset( $_POST['service_id'] )             ? sanitize_text_field( wp_unslash( $_POST['service_id'] ) )          : '';
        $status     = isset( $_POST['response_status'] )        ? sanitize_key( wp_unslash( $_POST['response_status'] ) )            : '';
        $reason     = isset( $_POST['response_reason'] )        ? sanitize_textarea_field( wp_unslash( $_POST['response_reason'] ) ) : '';
        $nonce      = isset( $_POST['crewboard_respond_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['crewboard_respond_nonce'] ) ) : '';

        if ( ! $event_id || ! $service_id || ! in_array( $status, array( 'accepted', 'denied' ), true ) ) {
            wp_die( 'Ungültige Anfrage.', 'CrewBoard', array( 'response' => 400 ) );
        }
        if ( ! wp_verify_nonce( $nonce, 'crewboard_respond_' . $event_id . '_' . $service_id ) ) {
            wp_die( 'Sicherheitsüberprüfung fehlgeschlagen.', 'CrewBoard', array( 'response' => 403 ) );
        }

        $user_id  = get_current_user_id();
        $services = self::get_services( $event_id );
        $found    = false;

        foreach ( $services as &$service ) {
            if ( ( $service['id'] ?? '' ) !== $service_id ) {
                continue;
            }
            $assigned = array_map( 'intval', $service['assigned'] ?? array() );
            if ( ! in_array( $user_id, $assigned, true ) ) {
                wp_die( 'Du bist nicht für diesen Dienst eingeteilt.', 'CrewBoard', array( 'response' => 403 ) );
            }
            $svc_responses = is_array( $service['responses'] ?? null ) ? $service['responses'] : array();
            $svc_responses[ (string) $user_id ] = array(
                'status' => $status,
                'reason' => $reason,
                'at'     => wp_date( 'Y-m-d\TH:i' ),
            );
            $service['responses'] = $svc_responses;
            $found = true;
            break;
        }
        unset( $service );

        if ( ! $found ) {
            wp_die( 'Dienst nicht gefunden.', 'CrewBoard', array( 'response' => 404 ) );
        }

        update_post_meta( $event_id, self::META_SERVICES, $services );

        if ( 'denied' === $status ) {
            self::notify_denial( $event_id, $service_id, $user_id, $reason, $services );
        }

        wp_safe_redirect( add_query_arg( 'crewboard', 'accepted' === $status ? 'responded_accepted' : 'responded_denied', self::portal_url() ) );
        exit;
    }

    public static function login_redirect( string $redirect_to, string $requested_redirect_to, $user ): string {
        if ( $user instanceof WP_User && ! user_can( $user, 'edit_posts' ) && ! self::can_manage_services( (int) $user->ID ) ) {
            return self::portal_url();
        }
        return $redirect_to;
    }


    private static function default_teams(): array {
        return array(
            'allgemein' => 'Allgemein',
            'theke'     => 'Theke',
            'technik'   => 'Technik',
            'einlass'   => 'Einlass',
            'aufbau'    => 'Aufbau',
            'reinigung' => 'Reinigung',
            'booking'   => 'Booking',
            'einkauf'   => 'Einkauf',
            'werbung'   => 'Werbung / Social Media',
        );
    }

    public static function teams(): array {
        $custom = get_option( self::OPTION_CUSTOM_TEAMS, array() );
        if ( ! is_array( $custom ) ) {
            $custom = array();
        }
        return array_merge( self::default_teams(), $custom );
    }

    private static function can_manage_members( int $user_id = 0 ): bool {
        $user_id = $user_id ?: get_current_user_id();
        return user_can( $user_id, 'manage_options' ) || 'board' === get_user_meta( $user_id, self::META_LEVEL, true );
    }

    private static function can_manage_services( int $user_id = 0 ): bool {
        $user_id = $user_id ?: get_current_user_id();
        return user_can( $user_id, 'manage_options' ) || in_array( get_user_meta( $user_id, self::META_LEVEL, true ), array( 'coordinator', 'board' ), true );
    }

    private static function user_is_eligible( int $user_id, string $team ): bool {
        if ( '' === $team ) {
            return '' !== get_user_meta( $user_id, self::META_LEVEL, true ) || user_can( $user_id, 'manage_options' );
        }
        $teams = get_user_meta( $user_id, self::META_TEAMS, true );
        return is_array( $teams ) && in_array( $team, $teams, true );
    }

    public static function admin_menu(): void {
        if ( ! self::can_manage_services() ) {
            return;
        }
        add_menu_page( 'CrewBoard', 'CrewBoard', 'read', 'crewboard', array( __CLASS__, 'render_admin_events' ), 'dashicons-groups', 27 );
        add_submenu_page( 'crewboard', 'Veranstaltungen', 'Veranstaltungen', 'read', 'crewboard', array( __CLASS__, 'render_admin_events' ) );
        if ( self::can_manage_members() ) {
            add_submenu_page( 'crewboard', 'Mitglieder', 'Mitglieder', 'read', 'crewboard-members', array( __CLASS__, 'render_admin_members' ) );
            add_submenu_page( 'crewboard', 'Einstellungen', 'Einstellungen', 'read', 'crewboard-settings', array( __CLASS__, 'render_admin_settings' ) );
        }
    }

    public static function render_admin_members(): void {
        if ( ! self::can_manage_members() ) {
            wp_die( 'Keine Berechtigung.' );
        }
        $all_users  = get_users( array( 'orderby' => 'display_name', 'order' => 'ASC' ) );
        $active     = array();
        $inactive   = array();
        foreach ( $all_users as $u ) {
            if ( '' !== (string) get_user_meta( $u->ID, self::META_LEVEL, true ) ) {
                $active[] = $u;
            } else {
                $inactive[] = $u;
            }
        }
        $teams      = self::teams();
        $col_count  = 2 + count( $teams );
        ?>
        <div class="wrap">
        <h1>CrewBoard – Mitglieder</h1>
        <?php if ( isset( $_GET['updated'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Änderungen gespeichert.</p></div><?php endif; ?>

        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="crewboard_save_members">
            <?php wp_nonce_field( 'crewboard_save_members' ); ?>

            <?php
            // ── Helper: render a single member row ────────────────────────
            $render_row = function( WP_User $user ) use ( $teams ): void {
                $level      = (string) get_user_meta( $user->ID, self::META_LEVEL, true );
                $user_teams = get_user_meta( $user->ID, self::META_TEAMS, true );
                $user_teams = is_array( $user_teams ) ? $user_teams : array();
                ?>
                <tr>
                    <td><strong><?php echo esc_html( $user->display_name ); ?></strong><br><small><?php echo esc_html( $user->user_email ); ?></small></td>
                    <td>
                        <select name="members[<?php echo esc_attr( (string) $user->ID ); ?>][level]">
                            <option value="" <?php selected( $level, '' ); ?>>Kein CrewBoard-Zugang</option>
                            <option value="member"      <?php selected( $level, 'member' ); ?>>Mitglied</option>
                            <option value="coordinator" <?php selected( $level, 'coordinator' ); ?>>Koordinator</option>
                            <option value="board"       <?php selected( $level, 'board' ); ?>>Vorstand</option>
                        </select>
                    </td>
                    <?php foreach ( $teams as $key => $label ) : ?>
                        <td><input type="checkbox" name="members[<?php echo esc_attr( (string) $user->ID ); ?>][teams][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $user_teams, true ) ); ?>></td>
                    <?php endforeach; ?>
                </tr>
                <?php
            };
            // Helper: render table head
            $render_head = function() use ( $teams ): void {
                ?><thead><tr><th>Person</th><th>CrewBoard-Stufe</th><?php foreach ( $teams as $label ) : ?><th><?php echo esc_html( $label ); ?></th><?php endforeach; ?></tr></thead><?php
            };
            ?>

            <!-- ── Section 1: active members ──────────────────────── -->
            <h2>Aktive Crew-Mitglieder
                <span class="title-count theme-count"><?php echo esc_html( (string) count( $active ) ); ?></span>
            </h2>
            <p class="description">Mitglieder mit CrewBoard-Zugang. Stufe und Teamzugehörigkeit können hier geändert werden.</p>
            <p><input type="search" id="crewboard-search-active" class="regular-text" placeholder="Aktive Mitglieder suchen …" autocomplete="off"></p>
            <table class="widefat striped" id="crewboard-members-active">
                <?php $render_head(); ?>
                <tbody>
                <?php if ( empty( $active ) ) : ?>
                    <tr><td colspan="<?php echo esc_attr( (string) $col_count ); ?>"><em>Noch keine aktiven Mitglieder.</em></td></tr>
                <?php else : ?>
                    <?php foreach ( $active as $u ) { $render_row( $u ); } ?>
                <?php endif; ?>
                </tbody>
            </table>

            <hr style="margin:32px 0">

            <!-- ── Section 2: add new members ─────────────────────── -->
            <h2>Mitglieder hinzufügen
                <span class="title-count theme-count"><?php echo esc_html( (string) count( $inactive ) ); ?></span>
            </h2>
            <p class="description">WordPress-Nutzer ohne CrewBoard-Zugang. Eine Stufe zuweisen, um sie zur Crew hinzuzufügen.</p>
            <p><input type="search" id="crewboard-search-inactive" class="regular-text" placeholder="Nutzer suchen …" autocomplete="off"></p>
            <table class="widefat striped" id="crewboard-members-inactive">
                <?php $render_head(); ?>
                <tbody>
                <?php if ( empty( $inactive ) ) : ?>
                    <tr><td colspan="<?php echo esc_attr( (string) $col_count ); ?>"><em>Alle WordPress-Nutzer sind bereits aktive Crew-Mitglieder.</em></td></tr>
                <?php else : ?>
                    <?php foreach ( $inactive as $u ) { $render_row( $u ); } ?>
                <?php endif; ?>
                </tbody>
            </table>

            <?php submit_button( 'Mitglieder speichern' ); ?>
        </form>
        </div><?php
    }

    public static function save_members(): void {
        if ( ! self::can_manage_members() ) {
            wp_die( 'Keine Berechtigung.' );
        }
        check_admin_referer( 'crewboard_save_members' );
        $members = isset( $_POST['members'] ) && is_array( $_POST['members'] ) ? wp_unslash( $_POST['members'] ) : array();
        foreach ( get_users( array( 'fields' => 'ID' ) ) as $user_id ) {
            $row = isset( $members[ $user_id ] ) && is_array( $members[ $user_id ] ) ? $members[ $user_id ] : array();
            $level = sanitize_key( $row['level'] ?? '' );
            if ( ! in_array( $level, array( '', 'member', 'coordinator', 'board' ), true ) ) {
                $level = '';
            }
            $teams = isset( $row['teams'] ) && is_array( $row['teams'] ) ? array_map( 'sanitize_key', $row['teams'] ) : array();
            $teams = array_values( array_intersect( array_keys( self::teams() ), $teams ) );
            update_user_meta( $user_id, self::META_LEVEL, $level );
            update_user_meta( $user_id, self::META_TEAMS, $teams );
        }
        wp_safe_redirect( add_query_arg( 'updated', '1', admin_url( 'admin.php?page=crewboard-members' ) ) );
        exit;
    }

    public static function render_admin_settings(): void {
        if ( ! self::can_manage_members() ) {
            wp_die( 'Keine Berechtigung.' );
        }
        $custom_teams = get_option( self::OPTION_CUSTOM_TEAMS, array() );
        if ( ! is_array( $custom_teams ) ) {
            $custom_teams = array();
        }
        ?>
        <div class="wrap"><h1>CrewBoard – Einstellungen</h1>
        <?php if ( isset( $_GET['updated'] ) ) : ?><div class="notice notice-success"><p>Einstellungen gespeichert.</p></div><?php endif; ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="crewboard_save_settings"><?php wp_nonce_field( 'crewboard_save_settings' ); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Selbstzuweisung</th>
                    <td><label><input type="checkbox" name="self_assign" value="1" <?php checked( get_option( self::OPTION_SELF_ASSIGN, '1' ), '1' ); ?>> Mitglieder dürfen freie, für ihr Team freigegebene Dienste selbst übernehmen.</label></td>
                </tr>
                <tr>
                    <th scope="row">Eigene Teams</th>
                    <td>
                        <p class="description">Zusätzliche Teams ergänzend zu den vordefinierten. Der interne Schlüssel wird automatisch aus dem Namen erzeugt.</p>
                        <div id="crewboard-custom-teams-list" style="margin:10px 0;display:flex;flex-direction:column;gap:6px">
                            <?php foreach ( $custom_teams as $label ) : ?>
                                <div class="crewboard-team-row" style="display:flex;gap:6px;align-items:center">
                                    <input type="text" name="custom_teams[]" value="<?php echo esc_attr( $label ); ?>" placeholder="Teamname" class="regular-text">
                                    <button type="button" class="button crewboard-remove-team">Entfernen</button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <p><button type="button" class="button" id="crewboard-add-team">+ Team hinzufügen</button></p>
                        <p class="description"><strong>Vordefinierte Teams:</strong> <?php echo esc_html( implode( ', ', array_values( self::default_teams() ) ) ); ?></p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form></div><?php
    }

    public static function save_settings(): void {
        if ( ! self::can_manage_members() ) {
            wp_die( 'Keine Berechtigung.' );
        }
        check_admin_referer( 'crewboard_save_settings' );
        update_option( self::OPTION_SELF_ASSIGN, isset( $_POST['self_assign'] ) ? '1' : '0' );

        $raw_teams    = isset( $_POST['custom_teams'] ) && is_array( $_POST['custom_teams'] ) ? wp_unslash( $_POST['custom_teams'] ) : array();
        $custom_teams = array();
        $default_keys = array_keys( self::default_teams() );
        foreach ( $raw_teams as $label ) {
            $label = sanitize_text_field( $label );
            if ( '' === $label ) { continue; }
            $key = sanitize_key( $label );
            if ( '' === $key || in_array( $key, $default_keys, true ) ) { continue; } // skip empty or collisions with defaults
            $custom_teams[ $key ] = $label;
        }
        update_option( self::OPTION_CUSTOM_TEAMS, $custom_teams );

        wp_safe_redirect( add_query_arg( 'updated', '1', admin_url( 'admin.php?page=crewboard-settings' ) ) );
        exit;
    }

    public static function render_admin_events(): void {
        if ( ! self::can_manage_services() ) {
            wp_die( 'Keine Berechtigung.' );
        }
        $event_id = isset( $_GET['event_id'] ) ? absint( $_GET['event_id'] ) : 0;
        $events = self::get_events_between( new DateTimeImmutable( '-3 months', wp_timezone() ), new DateTimeImmutable( '+18 months', wp_timezone() ) );
        ?>
        <div class="wrap"><h1>CrewBoard – Veranstaltungen</h1>
        <?php if ( isset( $_GET['updated'] ) ) : ?><div class="notice notice-success"><p>Dienste gespeichert.</p></div><?php endif; ?>
        <form method="get"><input type="hidden" name="page" value="crewboard"><select name="event_id"><option value="">Veranstaltung auswählen …</option><?php foreach ( $events as $event ) : ?><option value="<?php echo esc_attr( (string) $event->ID ); ?>" <?php selected( $event_id, $event->ID ); ?>><?php echo esc_html( self::event_date_label( $event ) . ' – ' . get_the_title( $event ) ); ?></option><?php endforeach; ?></select> <?php submit_button( 'Öffnen', 'secondary', '', false ); ?></form>
        <?php if ( $event_id && 'event' === get_post_type( $event_id ) ) : ?>
            <hr><h2><?php echo esc_html( get_the_title( $event_id ) ); ?></h2>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="crewboard_save_event_services"><input type="hidden" name="event_id" value="<?php echo esc_attr( (string) $event_id ); ?>">
                <?php wp_nonce_field( 'crewboard_save_event_services_' . $event_id ); ?>
                <?php self::render_services_editor( $event_id ); ?>
                <?php submit_button( 'Dienste speichern' ); ?>
            </form>
        <?php endif; ?></div><?php
    }

    private static function render_services_editor( int $event_id ): void {
        $services = self::get_services( $event_id );
        if ( empty( $services ) ) { $services[] = self::empty_service(); }
        $users = get_users( array( 'orderby' => 'display_name', 'order' => 'ASC', 'fields' => array( 'ID', 'display_name' ) ) );
        $users = array_values( array_filter( $users, static fn( $user ): bool => self::user_is_eligible( (int) $user->ID, '' ) ) );
        ?><table class="widefat striped" id="crewboard-services-table"><thead><tr><th>Dienst</th><th>Beginn</th><th>Ende</th><th>Bedarf</th><th>Team</th><th>Mitglieder</th><th></th></tr></thead><tbody><?php foreach ( $services as $index => $service ) { self::render_service_row( $index, $service, $users ); } ?></tbody></table>
        <p><button type="button" class="button" id="crewboard-add-service">+ Dienst hinzufügen</button></p><script type="text/template" id="crewboard-service-template"><?php self::render_service_row( '__INDEX__', self::empty_service(), $users ); ?></script><?php
    }

    public static function save_services_from_admin_page(): void {
        if ( ! self::can_manage_services() ) { wp_die( 'Keine Berechtigung.' ); }
        $event_id = isset( $_POST['event_id'] ) ? absint( $_POST['event_id'] ) : 0;
        check_admin_referer( 'crewboard_save_event_services_' . $event_id );
        if ( ! $event_id || 'event' !== get_post_type( $event_id ) ) { wp_die( 'Ungültige Veranstaltung.' ); }
        self::persist_services_from_request( $event_id );
        wp_safe_redirect( add_query_arg( array( 'page' => 'crewboard', 'event_id' => $event_id, 'updated' => '1' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    private static function persist_services_from_request( int $post_id ): void {
        $old_services = self::get_services( $post_id );

        // Index old services by UUID for quick response preservation.
        $old_by_id = array();
        foreach ( $old_services as $svc ) {
            if ( ! empty( $svc['id'] ) ) {
                $old_by_id[ $svc['id'] ] = $svc;
            }
        }

        $raw      = isset( $_POST['crewboard_services'] ) && is_array( $_POST['crewboard_services'] ) ? wp_unslash( $_POST['crewboard_services'] ) : array();
        $services = array();
        foreach ( $raw as $row ) {
            if ( ! is_array( $row ) ) { continue; }
            $title = sanitize_text_field( $row['title'] ?? '' );
            if ( '' === $title ) { continue; }
            $team = sanitize_key( $row['team'] ?? '' );
            if ( ! array_key_exists( $team, self::teams() ) ) { $team = ''; }
            $assigned = isset( $row['assigned'] ) && is_array( $row['assigned'] ) ? array_values( array_unique( array_filter( array_map( 'absint', $row['assigned'] ) ) ) ) : array();
            $assigned = array_values( array_filter( $assigned, static fn( int $uid ): bool => self::user_is_eligible( $uid, '' ) ) );

            $svc_id        = sanitize_text_field( $row['id'] ?? wp_generate_uuid4() );
            $old_svc       = $old_by_id[ $svc_id ] ?? null;
            $old_assigned  = $old_svc ? array_map( 'intval', $old_svc['assigned'] ?? array() ) : array();
            $old_responses = ( $old_svc && is_array( $old_svc['responses'] ?? null ) ) ? $old_svc['responses'] : array();

            // Keep response for users who remain; set pending for newly assigned users.
            $responses = array();
            foreach ( $assigned as $uid ) {
                $responses[ (string) $uid ] = in_array( $uid, $old_assigned, true )
                    ? ( $old_responses[ (string) $uid ] ?? array( 'status' => 'pending', 'reason' => '', 'at' => null ) )
                    : array( 'status' => 'pending', 'reason' => '', 'at' => null );
            }

            $services[] = array(
                'id'        => $svc_id,
                'title'     => $title,
                'start'     => self::sanitize_datetime_local( $row['start'] ?? '' ),
                'end'       => self::sanitize_datetime_local( $row['end'] ?? '' ),
                'needed'    => max( 1, min( 50, absint( $row['needed'] ?? 1 ) ) ),
                'team'      => $team,
                'assigned'  => $assigned,
                'responses' => $responses,
            );
        }
        update_post_meta( $post_id, self::META_SERVICES, $services );

        self::notify_assignment_changes( $post_id, $old_services, $services );
    }

    private static function notify_assignment_changes( int $post_id, array $old_services, array $new_services ): void {
        $event_title = get_the_title( $post_id );
        $site_name   = get_bloginfo( 'name' );
        $portal_url  = self::portal_url();

        // Index old assignments by service ID.
        $old_map = array();
        foreach ( $old_services as $svc ) {
            $old_map[ $svc['id'] ] = array(
                'title'    => $svc['title'],
                'assigned' => array_map( 'intval', $svc['assigned'] ?? array() ),
            );
        }

        // Index new assignments by service ID.
        $new_map = array();
        foreach ( $new_services as $svc ) {
            $new_map[ $svc['id'] ] = array(
                'title'    => $svc['title'],
                'assigned' => array_map( 'intval', $svc['assigned'] ?? array() ),
            );
        }

        // Notify users added or removed in existing / new services.
        foreach ( $new_map as $svc_id => $new_svc ) {
            $old_assigned = $old_map[ $svc_id ]['assigned'] ?? array();
            $added        = array_diff( $new_svc['assigned'], $old_assigned );
            $removed      = array_diff( $old_assigned, $new_svc['assigned'] );

            foreach ( $added as $user_id ) {
                $user = get_userdata( $user_id );
                if ( ! $user ) { continue; }
                wp_mail(
                    $user->user_email,
                    sprintf( '[%s] Du wurdest für einen Dienst eingeteilt', $site_name ),
                    sprintf(
                        "Hallo %s,\n\ndu wurdest für folgenden Dienst eingeteilt:\n\nVeranstaltung: %s\nDienst: %s\n\nDeine Dienste im CrewBoard:\n%s\n\nViele Grüße\n%s",
                        $user->display_name,
                        $event_title,
                        $new_svc['title'],
                        $portal_url,
                        $site_name
                    )
                );
            }

            foreach ( $removed as $user_id ) {
                $user = get_userdata( $user_id );
                if ( ! $user ) { continue; }
                wp_mail(
                    $user->user_email,
                    sprintf( '[%s] Deine Diensteinteilung wurde geändert', $site_name ),
                    sprintf(
                        "Hallo %s,\n\ndu wurdest aus folgendem Dienst ausgetragen:\n\nVeranstaltung: %s\nDienst: %s\n\nDeine aktuellen Dienste findest du hier:\n%s\n\nViele Grüße\n%s",
                        $user->display_name,
                        $event_title,
                        $new_svc['title'],
                        $portal_url,
                        $site_name
                    )
                );
            }
        }

        // Notify users whose entire service was deleted.
        foreach ( $old_map as $svc_id => $old_svc ) {
            if ( isset( $new_map[ $svc_id ] ) ) { continue; }
            foreach ( $old_svc['assigned'] as $user_id ) {
                $user = get_userdata( $user_id );
                if ( ! $user ) { continue; }
                wp_mail(
                    $user->user_email,
                    sprintf( '[%s] Deine Diensteinteilung wurde geändert', $site_name ),
                    sprintf(
                        "Hallo %s,\n\nder Dienst \"%s\" für die Veranstaltung \"%s\" wurde entfernt. Deine Einteilung für diesen Dienst ist damit hinfällig.\n\nDeine aktuellen Dienste findest du hier:\n%s\n\nViele Grüße\n%s",
                        $user->display_name,
                        $old_svc['title'],
                        $event_title,
                        $portal_url,
                        $site_name
                    )
                );
            }
        }
    }

    private static function notify_denial( int $event_id, string $service_id, int $denying_user_id, string $reason, array $services ): void {
        $member = get_userdata( $denying_user_id );
        if ( ! $member ) {
            return;
        }
        $event_title = get_the_title( $event_id );
        $site_name   = get_bloginfo( 'name' );
        $admin_url   = add_query_arg( array( 'page' => 'crewboard', 'event_id' => $event_id ), admin_url( 'admin.php' ) );
        $svc_title   = '';
        foreach ( $services as $svc ) {
            if ( ( $svc['id'] ?? '' ) === $service_id ) {
                $svc_title = $svc['title'];
                break;
            }
        }
        $reason_line = '' !== $reason ? "\n\nGrund: " . $reason : '';
        $subject     = sprintf( '[%s] Dienst abgelehnt von %s', $site_name, $member->display_name );
        $body_tpl    = "Hallo %s,\n\n" . sprintf(
            "%s hat den Dienst \"%s\" für die Veranstaltung \"%s\" abgelehnt.%s\n\nZur Übersicht:\n%s\n\nViele Grüße\n%s",
            $member->display_name,
            $svc_title,
            $event_title,
            $reason_line,
            $admin_url,
            $site_name
        );
        foreach ( get_users( array( 'fields' => array( 'ID', 'user_email', 'display_name' ) ) ) as $mgr ) {
            if ( (int) $mgr->ID === $denying_user_id || ! self::can_manage_services( (int) $mgr->ID ) ) {
                continue;
            }
            wp_mail( $mgr->user_email, $subject, sprintf( $body_tpl, $mgr->display_name ) );
        }
    }

    private static function portal_url(): string {
        $page_id = (int) get_option( self::PAGE_OPTION );
        return $page_id ? get_permalink( $page_id ) : home_url( '/intern/' );
    }

    private static function get_services( int $event_id ): array {
        $services = get_post_meta( $event_id, self::META_SERVICES, true );
        if ( ! is_array( $services ) ) {
            return array();
        }
        foreach ( $services as &$service ) {
            if ( empty( $service['id'] ) ) {
                $service['id'] = wp_generate_uuid4();
            }
        }
        unset( $service );
        return $services;
    }

    private static function get_events_between( DateTimeImmutable $start, DateTimeImmutable $end ): array {
        // Events Manager speichert Events als WordPress-Beitragstyp "event". Die Datumswerte
        // werden über EM_Event gelesen; der Query bleibt dadurch mit EM 7.x kompatibel.
        $query = new WP_Query(
            array(
                'post_type'      => 'event',
                'post_status'    => 'publish',
                'posts_per_page' => 300,
                'orderby'        => 'date',
                'order'          => 'ASC',
                'no_found_rows'  => true,
            )
        );
        $events = array();
        foreach ( $query->posts as $post ) {
            $date = self::event_start_date( $post );
            if ( $date && $date >= $start->setTime( 0, 0 ) && $date <= $end->setTime( 23, 59, 59 ) ) {
                $events[] = $post;
            }
        }
        usort(
            $events,
            static fn( WP_Post $a, WP_Post $b ): int => ( self::event_start_date( $a )?->getTimestamp() ?? PHP_INT_MAX ) <=> ( self::event_start_date( $b )?->getTimestamp() ?? PHP_INT_MAX )
        );
        return $events;
    }

    private static function event_start_date( WP_Post $event ): ?DateTimeImmutable {
        if ( class_exists( 'EM_Event' ) ) {
            try {
                $em_event = new EM_Event( $event->ID, 'post_id' );
                if ( ! empty( $em_event->event_start_date ) ) {
                    $time = ! empty( $em_event->event_start_time ) ? $em_event->event_start_time : '00:00:00';
                    $date = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', $em_event->event_start_date . ' ' . $time, wp_timezone() );
                    if ( $date ) {
                        return $date;
                    }
                }
            } catch ( Throwable $e ) {
                // Fallback below.
            }
        }

        foreach ( array( '_event_start_date', 'event_start_date' ) as $key ) {
            $raw = (string) get_post_meta( $event->ID, $key, true );
            if ( preg_match( '/^\d{4}-\d{2}-\d{2}/', $raw, $match ) ) {
                $date = DateTimeImmutable::createFromFormat( '!Y-m-d', $match[0], wp_timezone() );
                if ( $date ) {
                    return $date;
                }
            }
        }
        return null;
    }

    private static function event_date_label( WP_Post $event ): string {
        $date = self::event_start_date( $event );
        return $date ? wp_date( 'd.m.Y', $date->getTimestamp(), wp_timezone() ) : 'Termin offen';
    }

    private static function format_service_time( array $service, WP_Post $event ): string {
        if ( ! empty( $service['start'] ) ) {
            $start = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $service['start'], wp_timezone() );
            $end = ! empty( $service['end'] ) ? DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $service['end'], wp_timezone() ) : false;
            if ( $start ) {
                $text = wp_date( 'd.m., H:i', $start->getTimestamp(), wp_timezone() ) . ' Uhr';
                if ( $end ) {
                    $text .= ' – ' . wp_date( 'd.m., H:i', $end->getTimestamp(), wp_timezone() ) . ' Uhr';
                }
                return $text;
            }
        }
        return self::event_date_label( $event );
    }

    private static function event_has_user_service( int $event_id, int $user_id ): bool {
        foreach ( self::get_services( $event_id ) as $service ) {
            if ( in_array( $user_id, array_map( 'intval', $service['assigned'] ?? array() ), true ) ) {
                return true;
            }
        }
        return false;
    }
}

register_activation_hook( __FILE__, array( 'CrewBoard', 'activate' ) );
CrewBoard::init();
