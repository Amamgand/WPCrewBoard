document.addEventListener('DOMContentLoaded', () => {
  // ── Services table: add / remove rows ──────────────────
  const tableBody = document.querySelector('#crewboard-services-table tbody');
  const addButton = document.querySelector('#crewboard-add-service');
  const template = document.querySelector('#crewboard-service-template');
  if (tableBody && addButton && template) {
    const bindRemove = (root = document) => {
      root.querySelectorAll('.crewboard-remove-service').forEach((button) => {
        if (button.dataset.bound) return;
        button.dataset.bound = '1';
        button.addEventListener('click', () => button.closest('tr')?.remove());
      });
    };

    addButton.addEventListener('click', () => {
      const index = `${Date.now()}_${Math.floor(Math.random() * 1000)}`;
      const html = template.innerHTML.replaceAll('__INDEX__', index);
      tableBody.insertAdjacentHTML('beforeend', html);
      bindRemove(tableBody);
    });

    bindRemove();
  }

  // ── Members tables: live search (two sections) ─────────
  function bindTableSearch(inputId, tableId) {
    const input = document.getElementById(inputId);
    const table = document.getElementById(tableId);
    if (!input || !table) return;
    input.addEventListener('input', () => {
      const term = input.value.trim().toLowerCase();
      table.querySelectorAll('tbody tr').forEach(row => {
        const text = (row.querySelector('td')?.textContent ?? '').toLowerCase();
        // Use style.display — the `hidden` attr is overridden by WP admin CSS
        row.style.display = term !== '' && !text.includes(term) ? 'none' : '';
      });
    });
  }
  bindTableSearch('crewboard-search-active',   'crewboard-members-active');
  bindTableSearch('crewboard-search-inactive', 'crewboard-members-inactive');
  // Legacy single-table search (backwards compat if old markup still present)
  bindTableSearch('crewboard-member-search', 'crewboard-members-table');

  // ── Settings: custom teams add / remove ─────────────────
  const teamsList  = document.getElementById('crewboard-custom-teams-list');
  const addTeamBtn = document.getElementById('crewboard-add-team');
  if (teamsList && addTeamBtn) {
    const bindRemoveTeam = (root = teamsList) => {
      root.querySelectorAll('.crewboard-remove-team').forEach(btn => {
        if (btn.dataset.bound) return;
        btn.dataset.bound = '1';
        btn.addEventListener('click', () => btn.closest('.crewboard-team-row')?.remove());
      });
    };
    addTeamBtn.addEventListener('click', () => {
      const row = document.createElement('div');
      row.className = 'crewboard-team-row';
      row.style.cssText = 'display:flex;gap:6px;align-items:center';
      row.innerHTML = '<input type="text" name="custom_teams[]" placeholder="Teamname" class="regular-text"><button type="button" class="button crewboard-remove-team">Entfernen</button>';
      teamsList.appendChild(row);
      bindRemoveTeam(row);
      row.querySelector('input')?.focus();
    });
    bindRemoveTeam();
  }
});
